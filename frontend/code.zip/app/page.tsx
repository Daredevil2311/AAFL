"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

export default function Home() {
  const router = useRouter()
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
    // Redirect to login if not authenticated
    const user = localStorage.getItem("user")
    if (!user) {
      router.push("/login")
    } else {
      router.push("/upload")
    }
  }, [router])

  if (!isClient) return null

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-white mb-4">Loading...</h1>
      </div>
    </div>
  )
}
