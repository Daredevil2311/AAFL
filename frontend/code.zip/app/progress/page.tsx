"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { ArrowRight, Loader2 } from "lucide-react"

const STAGES = [
  "Initializing",
  "Loading model",
  "Preparing clients",
  "Running attacks",
  "Analyzing results",
  "Generating metrics",
  "Finalizing",
  "Complete",
]

export default function ProgressPage() {
  const router = useRouter()
  const [progress, setProgress] = useState(0)
  const [currentStage, setCurrentStage] = useState(0)
  const [logs, setLogs] = useState<string[]>([])
  const [isComplete, setIsComplete] = useState(false)
  const [isCancelled, setIsCancelled] = useState(false)

  useEffect(() => {
    const job = localStorage.getItem("currentJob")
    if (!job) {
      router.push("/upload")
      return
    }

    // Simulate progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsComplete(true)
          return 100
        }
        const increment = Math.random() * 15
        return Math.min(prev + increment, 100)
      })

      setCurrentStage((prev) => {
        if (prev < STAGES.length - 1) {
          return Math.floor((progress + Math.random() * 15) / (100 / STAGES.length))
        }
        return prev
      })

      setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] Processing stage ${currentStage}...`])
    }, 800)

    return () => clearInterval(interval)
  }, [progress, currentStage, router])

  const handleCancel = () => {
    setIsCancelled(true)
    router.push("/upload")
  }

  const handleComplete = () => {
    router.push("/results")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Simulation in Progress</h1>
          <p className="text-slate-400">Running federated learning attack simulation</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Progress */}
          <div className="lg:col-span-2 space-y-6">
            {/* Progress Card */}
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Overall Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-white">{Math.round(progress)}%</span>
                    {!isComplete && <Loader2 className="w-4 h-4 text-blue-400 animate-spin" />}
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
              </CardContent>
            </Card>

            {/* Stages */}
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Pipeline Stages</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {STAGES.map((stage, idx) => (
                    <div key={stage} className="flex items-center space-x-3">
                      <div
                        className={`w-3 h-3 rounded-full ${
                          idx < currentStage ? "bg-green-500" : idx === currentStage ? "bg-blue-500" : "bg-slate-700"
                        }`}
                      />
                      <span className={`text-sm ${idx <= currentStage ? "text-white" : "text-slate-500"}`}>
                        {stage}
                      </span>
                      {idx < STAGES.length - 1 && <ArrowRight className="w-3 h-3 text-slate-600 ml-auto" />}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Logs */}
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Execution Logs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-slate-950 rounded p-4 h-48 overflow-y-auto font-mono text-xs text-slate-300 space-y-1">
                  {logs.length === 0 ? (
                    <p className="text-slate-600">Waiting for logs...</p>
                  ) : (
                    logs.map((log, idx) => (
                      <p key={idx} className="text-slate-400">
                        {log}
                      </p>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Actions */}
          <div className="space-y-4">
            {!isComplete ? (
              <Button
                onClick={handleCancel}
                variant="outline"
                className="w-full bg-red-900/20 border-red-700 text-red-300 hover:bg-red-900/30"
              >
                Cancel Simulation
              </Button>
            ) : (
              <Button
                onClick={handleComplete}
                className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-medium"
              >
                View Results
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
