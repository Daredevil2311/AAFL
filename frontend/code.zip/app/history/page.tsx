"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Trash2 } from "lucide-react"

const mockHistory = [
  {
    id: "1",
    timestamp: new Date(Date.now() - 3600000).toLocaleString(),
    attackTypes: ["Label Flip", "Backdoor"],
    clientCount: 3,
    status: "completed",
    intensity: 50,
  },
  {
    id: "2",
    timestamp: new Date(Date.now() - 7200000).toLocaleString(),
    attackTypes: ["Scaling"],
    clientCount: 5,
    status: "completed",
    intensity: 75,
  },
  {
    id: "3",
    timestamp: new Date(Date.now() - 86400000).toLocaleString(),
    attackTypes: ["Manzanaran"],
    clientCount: 2,
    status: "cancelled",
    intensity: 30,
  },
]

export default function HistoryPage() {
  const router = useRouter()
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
    const user = localStorage.getItem("user")
    if (!user) {
      router.push("/login")
    }
  }, [router])

  if (!isClient) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Job History</h1>
            <p className="text-slate-400">View all past simulations</p>
          </div>
          <Button
            onClick={() => router.push("/upload")}
            variant="outline"
            className="bg-slate-800 border-slate-700 text-white hover:bg-slate-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </div>

        <div className="space-y-4">
          {mockHistory.map((job) => (
            <Card key={job.id} className="bg-slate-900 border-slate-700 hover:border-slate-600 transition">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-white font-medium mb-2">{job.timestamp}</p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {job.attackTypes.map((attack) => (
                        <Badge key={attack} variant="secondary" className="bg-slate-800 text-slate-300">
                          {attack}
                        </Badge>
                      ))}
                    </div>
                    <p className="text-slate-400 text-sm">
                      {job.clientCount} clients • {job.intensity}% intensity
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge className={job.status === "completed" ? "bg-green-600 text-white" : "bg-red-600 text-white"}>
                      {job.status}
                    </Badge>
                    <Button size="sm" variant="ghost" className="text-slate-400 hover:text-red-400">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
