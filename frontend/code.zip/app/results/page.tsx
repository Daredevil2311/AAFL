"use client"

import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { Download, ArrowLeft } from "lucide-react"

const mockData = [
  { client: "Client 1", baselineF1: 0.92, attackedF1: 0.78, drop: 0.14 },
  { client: "Client 2", baselineF1: 0.89, attackedF1: 0.82, drop: 0.07 },
  { client: "Client 3", baselineF1: 0.91, attackedF1: 0.65, drop: 0.26 },
]

export default function ResultsPage() {
  const router = useRouter()

  const avgBaselineF1 = (mockData.reduce((sum, d) => sum + d.baselineF1, 0) / mockData.length).toFixed(3)
  const avgAttackedF1 = (mockData.reduce((sum, d) => sum + d.attackedF1, 0) / mockData.length).toFixed(3)
  const avgDrop = (mockData.reduce((sum, d) => sum + d.drop, 0) / mockData.length).toFixed(3)

  const handleExport = () => {
    const csv = [
      ["Client", "Baseline F1", "Attacked F1", "Drop"],
      ...mockData.map((d) => [d.client, d.baselineF1, d.attackedF1, d.drop]),
    ]
      .map((row) => row.join(","))
      .join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "results.csv"
    a.click()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Simulation Results</h1>
            <p className="text-slate-400">Attack impact analysis and metrics</p>
          </div>
          <Button
            onClick={() => router.push("/upload")}
            variant="outline"
            className="bg-slate-800 border-slate-700 text-white hover:bg-slate-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="bg-slate-900 border-slate-700">
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-slate-400 text-sm mb-2">Baseline F1 Score</p>
                <p className="text-3xl font-bold text-white">{avgBaselineF1}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900 border-slate-700">
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-slate-400 text-sm mb-2">Attacked F1 Score</p>
                <p className="text-3xl font-bold text-white">{avgAttackedF1}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900 border-slate-700">
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-slate-400 text-sm mb-2">Average Drop</p>
                <p className="text-3xl font-bold text-red-400">{(Number.parseFloat(avgDrop) * 100).toFixed(1)}%</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <Card className="bg-slate-900 border-slate-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white">Per-Client Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={mockData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="client" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }}
                  labelStyle={{ color: "#f1f5f9" }}
                />
                <Legend />
                <Bar dataKey="baselineF1" fill="#3b82f6" name="Baseline F1" />
                <Bar dataKey="attackedF1" fill="#ef4444" name="Attacked F1" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Verdict */}
        <Card className="bg-slate-900 border-slate-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white">Attack Verdict</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockData.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-slate-800 rounded">
                  <span className="text-white">{item.client}</span>
                  <Badge
                    className={
                      item.drop > 0.2
                        ? "bg-red-600 text-white"
                        : item.drop > 0.1
                          ? "bg-yellow-600 text-white"
                          : "bg-green-600 text-white"
                    }
                  >
                    {item.drop > 0.2 ? "Compromised" : item.drop > 0.1 ? "Warning" : "Safe"}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Button
          onClick={handleExport}
          className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-medium"
        >
          <Download className="w-4 h-4 mr-2" />
          Export Results as CSV
        </Button>
      </div>
    </div>
  )
}
