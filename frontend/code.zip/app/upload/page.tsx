"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { LogOut } from "lucide-react"

const ATTACK_TYPES = [
  { id: "label-flip", name: "Label Flip", description: "Flip labels of training data" },
  { id: "manzanaran", name: "Manzanaran", description: "Poison model with bad data" },
  { id: "backdoor", name: "Backdoor", description: "Insert backdoor triggers" },
  { id: "cycle", name: "Cycle", description: "Cyclic perturbation attack" },
  { id: "freeride", name: "Freeride", description: "Free-riding attack" },
  { id: "scaling", name: "Scaling", description: "Scaling based attack" },
]

export default function UploadPage() {
  const router = useRouter()
  const [isClient, setIsClient] = useState(false)
  const [modelFile, setModelFile] = useState<File | null>(null)
  const [scriptFile, setScriptFile] = useState<File | null>(null)
  const [selectedAttacks, setSelectedAttacks] = useState<string[]>(["label-flip"])
  const [clientCount, setClientCount] = useState([3])
  const [intensity, setIntensity] = useState([50])
  const [isDemo, setIsDemo] = useState(true)

  useEffect(() => {
    setIsClient(true)
    const user = localStorage.getItem("user")
    if (!user) {
      router.push("/login")
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/login")
  }

  const handleStartSimulation = () => {
    const config = {
      modelFile: modelFile?.name || "demo-model.pkl",
      scriptFile: scriptFile?.name || "demo-script.py",
      selectedAttacks,
      clientCount: clientCount[0],
      intensity: intensity[0],
      isDemo,
      timestamp: new Date().toISOString(),
    }
    localStorage.setItem("currentJob", JSON.stringify(config))
    router.push("/progress")
  }

  const toggleAttack = (attackId: string) => {
    setSelectedAttacks((prev) => (prev.includes(attackId) ? prev.filter((a) => a !== attackId) : [...prev, attackId]))
  }

  if (!isClient) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">FedLearn Attack Simulator</h1>
            <p className="text-slate-400">Configure and run federated learning attack simulations</p>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="bg-slate-800 border-slate-700 text-white hover:bg-slate-700"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* File Upload Section */}
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Upload Files</CardTitle>
                <CardDescription className="text-slate-400">Upload your model and attack script files</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Model File Upload */}
                <div className="border-2 border-dashed border-slate-700 rounded-lg p-6 text-center hover:border-blue-500 transition cursor-pointer">
                  <input
                    type="file"
                    id="model"
                    className="hidden"
                    onChange={(e) => setModelFile(e.target.files?.[0] || null)}
                  />
                  <label htmlFor="model" className="cursor-pointer block">
                    <p className="text-sm text-slate-400">Drop model file here or click to browse</p>
                    {modelFile && <p className="text-blue-400 mt-2">{modelFile.name}</p>}
                  </label>
                </div>

                {/* Script File Upload */}
                <div className="border-2 border-dashed border-slate-700 rounded-lg p-6 text-center hover:border-blue-500 transition cursor-pointer">
                  <input
                    type="file"
                    id="script"
                    className="hidden"
                    onChange={(e) => setScriptFile(e.target.files?.[0] || null)}
                  />
                  <label htmlFor="script" className="cursor-pointer block">
                    <p className="text-sm text-slate-400">Drop script file here or click to browse</p>
                    {scriptFile && <p className="text-blue-400 mt-2">{scriptFile.name}</p>}
                  </label>
                </div>

                {/* Demo Mode Toggle */}
                <div className="flex items-center space-x-2 p-3 bg-slate-800 rounded">
                  <Checkbox checked={isDemo} onCheckedChange={(checked) => setIsDemo(checked as boolean)} id="demo" />
                  <label htmlFor="demo" className="text-sm text-white cursor-pointer">
                    Use Demo Mode (mock data)
                  </label>
                </div>
              </CardContent>
            </Card>

            {/* Attack Types Selection */}
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Select Attack Types</CardTitle>
                <CardDescription className="text-slate-400">Choose which attacks to simulate</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {ATTACK_TYPES.map((attack) => (
                    <div
                      key={attack.id}
                      className={`p-3 border rounded-lg cursor-pointer transition ${
                        selectedAttacks.includes(attack.id)
                          ? "bg-blue-900/30 border-blue-600"
                          : "bg-slate-800 border-slate-700 hover:border-slate-600"
                      }`}
                      onClick={() => toggleAttack(attack.id)}
                    >
                      <div className="flex items-start space-x-2">
                        <Checkbox
                          checked={selectedAttacks.includes(attack.id)}
                          onCheckedChange={() => toggleAttack(attack.id)}
                          id={attack.id}
                        />
                        <div>
                          <p className="font-medium text-white text-sm">{attack.name}</p>
                          <p className="text-xs text-slate-400">{attack.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Client Configuration */}
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Clients */}
                <div>
                  <label className="text-sm font-medium text-white block mb-3">
                    Number of Clients: <span className="text-blue-400">{clientCount[0]}</span>
                  </label>
                  <Slider
                    value={clientCount}
                    onValueChange={setClientCount}
                    min={1}
                    max={5}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-slate-500 mt-2">
                    <span>1</span>
                    <span>5</span>
                  </div>
                </div>

                {/* Intensity */}
                <div>
                  <label className="text-sm font-medium text-white block mb-3">
                    Attack Intensity: <span className="text-blue-400">{intensity[0]}%</span>
                  </label>
                  <Slider
                    value={intensity}
                    onValueChange={setIntensity}
                    min={0}
                    max={100}
                    step={5}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-slate-500 mt-2">
                    <span>0%</span>
                    <span>100%</span>
                  </div>
                </div>

                {/* Start Button */}
                <Button
                  onClick={handleStartSimulation}
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-medium mt-8"
                >
                  Start Simulation
                </Button>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Quick Links</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-blue-400 hover:text-blue-300 hover:bg-slate-800"
                  onClick={() => router.push("/history")}
                >
                  View Job History
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
