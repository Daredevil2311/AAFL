"use client"

import React, { createContext, useState, useCallback, type ReactNode } from "react"
import type { AuthContextType } from "../types"

export const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null)
  const [token, setToken] = useState<string | null>(null)

  // Initialize from localStorage
  React.useEffect(() => {
    const stored = localStorage.getItem("auth")
    if (stored) {
      const { user, token } = JSON.parse(stored)
      setUser(user)
      setToken(token)
    }
  }, [])

  const login = useCallback(async (email: string, password: string) => {
    // Mock validation
    if (!email.includes("@") || password.length < 8) {
      throw new Error("Invalid email or password")
    }
    const mockUser = { id: `user-${Date.now()}`, email }
    const mockToken = `token-${Date.now()}`
    setUser(mockUser)
    setToken(mockToken)
    localStorage.setItem("auth", JSON.stringify({ user: mockUser, token: mockToken }))
  }, [])

  const signup = useCallback(async (email: string, password: string) => {
    if (!email.includes("@") || password.length < 8) {
      throw new Error("Invalid email or password length must be >= 8")
    }
    const mockUser = { id: `user-${Date.now()}`, email }
    const mockToken = `token-${Date.now()}`
    setUser(mockUser)
    setToken(mockToken)
    localStorage.setItem("auth", JSON.stringify({ user: mockUser, token: mockToken }))
  }, [])

  const logout = useCallback(() => {
    setUser(null)
    setToken(null)
    localStorage.removeItem("auth")
  }, [])

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        login,
        signup,
        logout,
        isAuthenticated: !!token,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = React.useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider")
  }
  return context
}
