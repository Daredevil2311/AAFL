/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}", "*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        background: '#0f1117',
        foreground: '#e6edf3',
        primary: '#1f6feb',
        secondary: '#30363d',
        accent: '#58a6ff',
        destructive: '#f85149',
        success: '#3fb950',
        warning: '#d29922',
        muted: '#6e7681',
      },
    },
  },
  plugins: [],
}
